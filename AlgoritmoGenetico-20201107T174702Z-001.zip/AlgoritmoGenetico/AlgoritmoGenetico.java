import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

/**
 * O algoritmo genético.
 *
 * @author Vinicius Carneiro, Henrique Moreira, Leonardo
 */
public class AlgoritmoGenetico {

    private ArrayList<Individuo> populacao;
    private final int tamPopulacao;
    private int caminhoTotal, caminhoMinIndivido;
    private int caminhoFeito[];

    DefaultCategoryDataset dataset = new DefaultCategoryDataset();

    /**
     * Constrói um algoritmo genético.
     *
     * @param tamTabuleiro o tamanho do tabuleiro n x n
     * @param tamPopulacao o número de indivíduos
     */
    public AlgoritmoGenetico(int matrizDistancia[][], int tamPopulacao, int menorAresta) {
        this.tamPopulacao = tamPopulacao;
        this.caminhoMinIndivido = menorAresta;
        populacao = new ArrayList<>();
        geraPopulacaoInicial(matrizDistancia);
    }

    /**
     * A soma de aptidão de todos os indivíduos da população.
     */
    private void calculaAptidaoTotal() {

        this.caminhoTotal = 0;

        for (Individuo i : populacao) {
            this.caminhoTotal += i.getAptidao();

        }
        System.out.println("calculaAptidaoTotal " + this.caminhoTotal);
    }

    /**
     * Ordena uma população por sua aptidão de maneira Crescente.
     *
     * @param populacao a população
     */
    private void ordenaPopulacao(ArrayList<Individuo> populacao) {
        Collections.sort(populacao, new Comparator<Individuo>() {
            @Override
            public int compare(Individuo i1, Individuo i2) {
                return i1.getAptidao() - i2.getAptidao();
            }
        });
    }

    /**
     * Gera a população inicial.
     *
     * @param tamTabuleiro o tamanho do tabuleiro n x n
     */
    private void geraPopulacaoInicial(int matrizDistancia[][]) {
        //Random r = new Random();
        for (int i = 0; i < tamPopulacao; i++) {
            populacao.add(new Individuo(matrizDistancia.length, matrizDistancia));
        }
        ordenaPopulacao(populacao);

        System.out.println("Individiuos gerados inicialmente");
        int i = 0;
        while (i < 100) {
            populacao.get(i).exibeIndividuo();
            i++;
        }

        calculaAptidaoTotal();
    }

    /**
     * Executa o algoritmo genético com base nas suas configurações.
     *
     * @param nGeracoes      o número de gerações máximo que deve ser computado
     * @param corteCrossover o ponto de corte para o crossover na geração de
     *                       novos indivíduos
     * @param taxaMutacao    a taxa de mutação (0..100)
     * @param metodo         o método de seleção de indivíduos para crossover ->
     *                       "roleta" ou "torneio"
     * @param elitismo       quantos elementos serão movidos para a próxima geração
     *                       através do elitismo
     **/
    public void executa(int nGeracoes, int corteCrossover, int taxaMutacao, String metodo, int elitismo, int matrizDistancia[][], int qtsCombatentes) {
        int i = 0;
        //&& populacao.get(0).getAptidao() != caminhoMinIndivido

        if (metodo.equals("roleta")) {
            System.out.println("O metodo escolhido é: "+metodo);
        } else {
            System.out.println("O metodo escolhido é: "+metodo+" com "+qtsCombatentes+" combatentes.");
        }

        while (i < nGeracoes) {
            System.out.println("Geração " + i + "\nTamanho populacao: " + populacao.size() + "\nAptidao media:" + (caminhoTotal / populacao.size()));
            System.out.println("Melhor indivíduo: ");
            populacao.get(0).exibeIndividuo();
            System.out.println("--------------------------------\n");
            //Grafico aqui
            if (i%5==0){
                int aptMedia = caminhoTotal / populacao.size();
                System.out.println("AptMedia"+aptMedia);
                String nome = "G " + i;
                double n = (caminhoTotal / populacao.size());

                dataset.addValue(n, "Taxa", nome);
            }


            //geraNovaPopulacao(int corteCrossover, int taxaMutacao, String metodo, int elitismo)
            geraNovaPopulacao(corteCrossover, taxaMutacao, metodo, elitismo, matrizDistancia, qtsCombatentes);
            i++;
        }
        System.out.println("Solucao vencedora: ");
        populacao.get(0).exibeIndividuo();

        //Grafico aqui

        JFreeChart chart = ChartFactory.createLineChart(
                "Aptidão Média x Número de Geração",
                "Número de Geração",
                "Aptidão Média",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        chart.setBackgroundPaint(Color.white);
        chart.getTitle().setPaint(Color.black);
        CategoryPlot p = chart.getCategoryPlot();
        p.setForegroundAlpha(0.9f);
        p.setRangeGridlinePaint(Color.red);
        p.setDomainGridlinesVisible(true);
        p.setDomainGridlinePaint(Color.black);
        CategoryItemRenderer renderer = p.getRenderer();
        //renderer.setSeriesPaint(1, Color.red);
        //renderer.setSeriesPaint(1, Color.green);
        ChartFrame frame1 = new ChartFrame("Grafico de linhas - Algoritmo Genético", chart);
        frame1.setVisible(true);
        frame1.setSize(1000,500);


    }

    /**
     * Gera uma nova população e substitui a antiga.
     *
     * @param corteCrossover o ponto de corte para o crossover na geração de
     *                       novos indivíduos
     * @param taxaMutacao    a taxa de mutação (0..100)
     * @param metodo         o método de seleção de indivíduos para crossover ->
     *                       "roleta" ou "torneio"
     * @param elitismo       quantos elementos serão movidos para a próxima geração
     *                       através do elitismo
     **/

    private void geraNovaPopulacao(int corteCrossover, int taxaMutacao, String metodo, int elitismo, int matrizDistancia[][], int qtsCombatentes) {
        ArrayList<Individuo> novaPopulacao = new ArrayList<>();
        Random r = new Random();

        if (elitismo > 0) { // se houver elitismo, transfere o número designado para a próxima população
            int i = 0;
            while (i < elitismo) {
                novaPopulacao.add(populacao.get(i));//populacao.add(new Individuo(matrizDistancia.length, matrizDistancia));
                i++;
            }
        }

        //enquanto a nova população não tiver o tamanho da original
        //ou for maior (pode ocorrer devido elitismo ou população de tamanho ímpar).
        while (novaPopulacao.size() < populacao.size()) {
            Individuo i1, i2;

            //seleciona dos indivíduos através de roleta ou torneio
            if (metodo.equals("roleta")) {
                i1 = selecionaRoleta();
                i2 = selecionaRoleta();
            } else {
                i1 = selecionaTorneio(qtsCombatentes);
                i2 = selecionaTorneio(qtsCombatentes);
            }
            //System.out.println("\ngeraNovaPopulacao aqui\n");
            //cria dois novos indivíduos, e efetua mutação caso necessário
            novaPopulacao.add(new Individuo(i1.getGenotipo(), i2.getGenotipo(), caminhoMinIndivido, corteCrossover, matrizDistancia));
            if (r.nextInt(100) < taxaMutacao) {
                novaPopulacao.get(novaPopulacao.size() - 1).muta();
            }
            novaPopulacao.add(new Individuo(i2.getGenotipo(), i1.getGenotipo(), caminhoMinIndivido, corteCrossover, matrizDistancia));
            if (r.nextInt(100) < taxaMutacao) {
                novaPopulacao.get(novaPopulacao.size() - 1).muta();
            }
        }
        ordenaPopulacao(novaPopulacao);

        //se a nova população for maior que a original, remove o(s) mais inapto(s)
        while (novaPopulacao.size() > populacao.size()) {
            novaPopulacao.remove(novaPopulacao.size() - 1);
        }

        populacao = novaPopulacao;

        System.out.println("Novos Individiuos gerados");
        int i = 0;
        while (i < 100) {
            populacao.get(i).exibeIndividuo();
            i++;
        }

        calculaAptidaoTotal();
    }

    /**
     * Implementa o método da roleta.
     *
     * @return um indivíduo
     */
    private Individuo selecionaRoleta() {

        //System.out.println("caminhoTotal "+caminhoTotal);

        Random r = new Random();
        //int valor = r.nextInt(caminhoTotal); //escolhe um valor da roleta
        int valor = r.nextInt(caminhoTotal); //escolhe um valor da roleta
        int i;

        //vai reduzindo o valor até achar o indivíduo correspondente
        for (i = populacao.size() - 1; i > 0; i--) {
            valor += populacao.get(i).getAptidao();
            if (valor <= populacao.size()) {
                break;
            }
        }

        return populacao.get(i);
    }

    /**
     * Implementa o método do torneio, com apenas dois indivíduos competindo.
     *
     * @return um indivíduo
     */
    private Individuo selecionaTorneio(int qtsCombatentes) {
        Random r = new Random();
        //int qtsCombatentes = 4;
        //seleciona dois indivíduos aleatoriamente
        int[] selecionados;
        selecionados = new int[qtsCombatentes];
        int oMelhor = 0;
        //System.out.println("Torneio começando");

        for (int i = 0; i < qtsCombatentes; i++) {
            selecionados[i] = r.nextInt(populacao.size());
            //System.out.println("O " + i + " aptidao:" + populacao.get(selecionados[i]).getAptidao() + " numero:" + selecionados[i]);
            // System.out.println("oMelhor antes"+oMelhor);
            if (i == 0) {
                oMelhor = selecionados[i];
            }
            if (populacao.get(selecionados[i]).getAptidao() < populacao.get(oMelhor).getAptidao()) {
                oMelhor = selecionados[i];
                //System.out.println("o melhor selecionado: "+oMelhor);
            }


        }

        //System.out.println("Resultado do torneio:" + oMelhor);


        //escolhe qual é o maior e o retorna
        return populacao.get(oMelhor);

    }

}

