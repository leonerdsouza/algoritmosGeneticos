import java.util.Arrays;
import java.util.Random;

/**
 * Um indivíduo que representa um estado final do tabuleiro (todas as rainhas
 * posicionadas)
 *
 * @author Rafael D'Addio
 */
public class Individuo {

    //representação decimal -> 0..n colunas com valores correspondentes a
    //posição da rainha em uma das 0..n linhas
    private int[] genotipo;

    private int aptidao; //função de aptidão -> numero de não-colisões

    /**
     * Constroi um individuo para a população inicial
     *
     * @param n tamanho do genótipo
     * @param aptidaoMax valor máximo de não-colisões para determinado tamanho
     * de tabuleiro
     */
    /*Individuo(matrizDistancia.length, matrizDistancia));*/
    public Individuo(int tamanho,int matrizDistancia[][]) {
        genotipo = new int[tamanho];
        geraGenotipoAleatorio();
        calcAptidao(matrizDistancia);
    }

    /**
     * Constroi um individuo a partir de um pai e uma mãe
     *
     * @param pai o genótipo do pai
     * @param mae o genótipo da mãe
     * @param aptidaoMax valor máximo de não-colisões para determinado tamanho
     * de tabuleiro
     * @param corteCrossover onde fazer o corte para mistura de genótipos
     */

    //(i1.getGenotipo(), i2.getGenotipo(), caminhoMinIndivido, corteCrossover)
    public Individuo(int[] pai, int[] mae, int aptidaoMax, int corteCrossover, int matrizDistancia[][]) {
        genotipo = new int[pai.length];
        crossOver(pai, mae, corteCrossover);
        calcAptidao(matrizDistancia);
    }

    /**
     * Constroi um genótipo aleatório para um indivíduo.
     *
     */
    private void geraGenotipoAleatorio() {
        Random r = new Random();
        //um caminho de 5 posições com  matrizDistancia.length numeros aleatorios
        // for (int i = 0; i < getGenotipo().length; i++) {
        genotipo[0] = 0;
        genotipo[getGenotipo().length - 1] = getGenotipo().length-1;
        for (int y = 1; y < (getGenotipo().length - 1); y++) {
            int valor = 1 + r.nextInt(getGenotipo().length - 2);
            if (valor == -1){
                do{
                    r = new Random();
                    valor = 1 + r.nextInt(getGenotipo().length - 2);
                }while (valor != -1);
            }
            genotipo[y] =  valor;// Gera números aleatórios com limite 50 e minimo 10.
        }
        //System.out.println("Genotipo (caminho)");
        //for (int y = 0; y < (getGenotipo().length); y++) {
            //System.out.print( (genotipo[y]+1)+"->");
        //}
        //System.out.println(" ");
        //}
    }
    /**
     * Calcula a aptidão do indivíduo. A aptidão é uma função referente à
     * quantidade de pares de rainhas que não se colidem no tabuleiro.
     *
     * @param aptidaoMax valor máximo de não-colisões para determinado
     * tamanho de tabuleiro
     */
    private void calcAptidao(int matrizDistancia[][]) {

        //System.out.println("getGenotipo().length"+getGenotipo().length);
        //System.out.println("a:" + genotipo[4]);

        for (int y = 0; y < (getGenotipo().length-1); y++) {

            //System.out.println("y: "+(y));
            //System.out.println("origem "+ genotipo[y+1]);

            int valor = matrizDistancia[genotipo[y]][genotipo[(y+1)]];

            if (valor == -1){
                aptidao = 100;
                break;
            }else{
                aptidao += valor;
            }



            //aptidao += matrizDistancia[genotipo[y]][genotipo[(y+1)]];
        }
        //System.out.println("Aptidao do individuo "+ this.aptidao+"\n");
    }

    /**
     * Realiza o crossover entre pai e mae produzindo um filho
     *
     * @param pai o genótipo do pai
     * @param mae o genótipo da mãe
     * @param corteCrossover onde fazer o corte para mistura de genótipos
     */
    private void crossOver(int[] pai, int[] mae, int corteCrossover) {

        //copia a parte inicial do pai
        //System.arraycopy(pai, 1, genotipo, 1, corteCrossover);
        //copia a parte final da mãe
        //System.arraycopy(mae, corteCrossover, genotipo, corteCrossover, genotipo.length - corteCrossover);

        if (corteCrossover == -1){
            Random r = new Random();

            int randomNum = r.nextInt(((genotipo.length-2) - 1) + 1) + 1;

            System.arraycopy(pai, 0, genotipo, 0, randomNum); //copia a parte inicial do pai
            System.arraycopy(mae, randomNum, genotipo, randomNum, genotipo.length - randomNum); //copia a parte final da mãe

        }else{
            System.arraycopy(pai, 0, genotipo, 0, corteCrossover); //copia a parte inicial do pai
            System.arraycopy(mae, corteCrossover, genotipo, corteCrossover, genotipo.length - corteCrossover); //copia a parte final da mãe
        }



    }

    /**
     * Realiza a mutação da posição de uma rainha em uma coluna aleatória.
     */
    public void muta() {
        Random r = new Random();

        int randomNum = r.nextInt(((genotipo.length-2) - 1) + 1) + 1;
        int posicao = r.nextInt(((genotipo.length-2) - 1) + 1) + 1;

        //System.out.println("Posicao:" +posicao+" Numero: "+randomNum);

        genotipo[posicao] = randomNum;
    }

    /**
     * Exibe o indivíduo.
     */
    public void exibeIndividuo() {
        int[][] m = new int[getGenotipo().length][getGenotipo().length];
        //System.out.print("Genótipo: ");
        for (int i = 0; i < getGenotipo().length; i++) {
            m[getGenotipo()[i]][i] = 1;
            System.out.print(getGenotipo()[i] + " ");
        }

        System.out.println("Aptidão = " + getAptidao());
    }

    /**
     * @return a aptidao
     */
    public int getAptidao() {
        return aptidao;
    }

    /**
     * @return o genotipo
     */
    public int[] getGenotipo() {
        return genotipo;
    }

}
