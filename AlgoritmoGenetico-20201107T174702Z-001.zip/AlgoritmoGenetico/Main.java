import jdk.jfr.Category;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.resources.JFreeChartResources;
import org.jfree.data.category.DefaultCategoryDataset;


/**
 * O algoritmo genético.
 *
 * @author Vinicius Carneiro, Henrique Moreira, Leonardo
 */

import java.awt.*;
import java.io.*;

public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException {

        int menorAresta = 10000;
        System.out.println("Ola, certifique que vc mudou o diretorio no programa de acordo com seu computador");

        String diretorio;
        diretorio = "C:\\Users\\Homirrimo\\Documents\\Engenharia de Computação\\TSI\\Trabalho Menor Rota\\GitHub\\caminho-otimizado\\grafos\\0005.txt";

        //String diretorio = C:\\Users\\vinic\\Desktop\\caminhootimizado\\src\\main\\java\\caminhootimizado\\grafos\\0005.txt";

        System.out.println("O diretorio onde está o arquivo é:\n" + diretorio + "\n");

        //Este trecho encontra a largura/altura da minha matriz
        LineNumberReader lineCounter = new LineNumberReader(new InputStreamReader(new FileInputStream(diretorio)));
        //pega a primeira linha da matriz
        String nextLine = lineCounter.readLine();

        //divide a linha da matriz em colunas
        String[] split = nextLine.split(" ");

        int tamanhoMatriz = split.length;
        //Cria a matriz do tamanho encontrado
        int matrizDistancia[][] = new int[tamanhoMatriz][tamanhoMatriz];
        //Reseta a posição das linhas
        lineCounter = new LineNumberReader(new InputStreamReader(new FileInputStream(diretorio)));

        System.out.println("Matriz do Grafo:");
        //Enquanto houver linha...
        while ((nextLine = lineCounter.readLine()) != null) {
            System.out.println(" " + nextLine);

            split = nextLine.split(" ");
            tamanhoMatriz = split.length;
            //Alimento a matriz com os pesos em cada lugar
            for (int k = 0; k < tamanhoMatriz; k++) {
                //if ((Integer.valueOf(split[k])) != 0) {
                int peso = (Integer.valueOf(split[k]));
                int origem = lineCounter.getLineNumber() - 1;
                int destino = k;
                //System.out.println("linha" + origem);
                // System.out.println("destino" + destino);
                if (peso < menorAresta && peso != 0) {
                    menorAresta = peso;
                }
                matrizDistancia[origem][destino] = peso;
                //System.out.println("matrizDistancia" + matrizDistancia[origem][destino]);
                //}
            }
        }
        System.out.println("\nMenor valor das aresta:" + menorAresta + "\n");

        // AlgoritmoGenetico(int matrizDistancia[][], int tamPopulacao, int menorAresta)
        AlgoritmoGenetico ag = new AlgoritmoGenetico(matrizDistancia, 250, menorAresta);

        // executa(int nGeracoes, int corteCrossover, int taxaMutacao, String metodo, int elitismo, int matrizDistancia[][], int qtsCombatentes)
        ag.executa(100, 2, 5, "roleta", 15, matrizDistancia, 4);

    }
}
